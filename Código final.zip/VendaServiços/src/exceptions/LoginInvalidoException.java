package exceptions;

public class LoginInvalidoException extends Exception {
	public LoginInvalidoException()
	{
		super("Login inv�lido");
	}

}
